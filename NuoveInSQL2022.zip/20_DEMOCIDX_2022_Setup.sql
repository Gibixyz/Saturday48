-- Create the data warehouse
USE master;

GO
IF EXISTS(SELECT * FROM sys.sysdatabases WHERE name = 'DEMODW22')
	DROP DATABASE DEMODW19;
GO

CREATE DATABASE DEMODW22
ON 
  ( NAME = DEMODW22_dat,
      FILENAME = 'D:\SQL2022Data\DEMODW22dat.mdf',
      SIZE = 65536 MB,
      MAXSIZE = UNLIMITED,
      FILEGROWTH = 512 MB )
  LOG ON
  ( NAME = DEMODW22_log,
      FILENAME = 'C:\SQL2022Logs\DEMODW22log.ldf',
      SIZE = 65536 MB,
      MAXSIZE = UNLIMITED,
      FILEGROWTH = 512 MB ) ;
  GO

ALTER DATABASE DEMODW22
SET RECOVERY SIMPLE;
 
-- Create the DimDate dimension table
USE DEMODW22;
GO
CREATE TABLE [dbo].[DimDate](
	[DateKey] [int] NOT NULL,
	[FullDateAlternateKey] [date] NOT NULL,
	[DayNumberOfWeek] [tinyint] NOT NULL,
	[DayNameOfWeek] [nvarchar](10) NOT NULL,
	[DayNumberOfMonth] [tinyint] NOT NULL,
	[MonthName] [nvarchar](10) NOT NULL,
	[MonthNumberOfYear] [tinyint] NOT NULL,
	[CalendarYear] [smallint] NOT NULL,
);

-- Populate DimDate with values from 2 years ago until the end of this month
DECLARE @StartDate datetime
DECLARE @EndDate datetime
SET @StartDate = dateadd(year,-4, getdate())
SET @EndDate = dateadd(year, 1, getdate())
DECLARE @LoopDate datetime
SET @LoopDate = @StartDate
WHILE @LoopDate <= @EndDate
BEGIN
  INSERT INTO dbo.DimDate VALUES
	(
		CAST(CONVERT(VARCHAR(8), @LoopDate, 112) AS int) , -- date key
		@LoopDate, -- date alt key
		datepart(dw, @LoopDate), -- day number of week
		datename(dw, @LoopDate), -- day name of week
	    Day(@LoopDate),  -- day number of month
		datename(mm, @LoopDate), -- month name
		Month(@LoopDate), -- month number of year
		Year(@LoopDate) -- calendar year
	)  		  
	SET @LoopDate = DateAdd(dd, 1, @LoopDate)
END;

-- Create indexes on the DimDate table
CREATE CLUSTERED INDEX cids_Dimdate_DateKey ON DimDate(DateKey);
CREATE NONCLUSTERED INDEX idx_DimDate_MonthNumberOfYear ON DimDate(MonthNumberOfYear);
CREATE NONCLUSTERED INDEX idx_DimDate_CalendarYear ON DimDate(CalendarYear);


-- Create the DimCustomer table
CREATE TABLE DimCustomer
(CustomerKey integer NOT NULL,
 CustomerAltKey varchar(10) NOT NULL,
 CustomerParentKey integer NULL,
 CustomerName nvarchar(100) NOT NULL,
 CustomerType nvarchar(100) NOT NULL);
INSERT INTO DimCustomer
VALUES (1, '000001', NULL, 'World Wide Importers', 'Retail');
INSERT INTO DimCustomer
VALUES (2, '000002', NULL, 'Margies Travel', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (3, '000003', NULL, 'Coho Vineyard and Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (4, '000004', NULL, 'Contoso Ltd', 'Retail');
INSERT INTO DimCustomer
VALUES (5, '000005', 1, 'Northwind Traders', 'Retail');
INSERT INTO DimCustomer
VALUES (6, '000006', 2, 'Blue Yonder Airlines', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (7, '000007', 3, 'Coho Vineyard', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (8, '000008', 3, 'Coho Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (9, '000009', 4, 'Fabrikam Inc', 'Retail');
INSERT INTO DimCustomer
VALUES (10, '000010', 2, 'Alpine Ski House', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (11, '000011', NULL, 'World Wide Importers', 'Retail');
INSERT INTO DimCustomer
VALUES (12, '000012', NULL, 'Margies Travel', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (13, '000013', NULL, 'Coho Vineyard and Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (14, '000014', NULL, 'Contoso Ltd', 'Retail');
INSERT INTO DimCustomer
VALUES (15, '000015', 1, 'Northwind Traders', 'Retail');
INSERT INTO DimCustomer
VALUES (16, '000016', 2, 'Blue Yonder Airlines', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (17, '000017', 3, 'Coho Vineyard', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (18, '000018', 3, 'Coho Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (19, '000019', 4, 'Fabrikam Inc', 'Retail');
INSERT INTO DimCustomer
VALUES (20, '000020', 2, 'Alpine Ski House', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (21, '000021', NULL, 'World Wide Importers', 'Retail');
INSERT INTO DimCustomer
VALUES (22, '000022', NULL, 'Margies Travel', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (23, '000023', NULL, 'Coho Vineyard and Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (24, '000024', NULL, 'Contoso Ltd', 'Retail');
INSERT INTO DimCustomer
VALUES (25, '000025', 1, 'Northwind Traders', 'Retail');
INSERT INTO DimCustomer
VALUES (26, '000026', 2, 'Blue Yonder Airlines', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (27, '000027', 3, 'Coho Vineyard', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (28, '000028', 3, 'Coho Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (29, '000029', 4, 'Fabrikam Inc', 'Retail');
INSERT INTO DimCustomer
VALUES (30, '000030', 2, 'Alpine Ski House', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (31, '000031', NULL, 'World Wide Importers', 'Retail');
INSERT INTO DimCustomer
VALUES (32, '000032', NULL, 'Margies Travel', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (33, '000033', NULL, 'Coho Vineyard and Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (34, '000034', NULL, 'Contoso Ltd', 'Retail');
INSERT INTO DimCustomer
VALUES (35, '000035', 1, 'Northwind Traders', 'Retail');
INSERT INTO DimCustomer
VALUES (36, '000036', 2, 'Blue Yonder Airlines', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (37, '000037', 3, 'Coho Vineyard', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (38, '000038', 3, 'Coho Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (39, '000039', 4, 'Fabrikam Inc', 'Retail');
INSERT INTO DimCustomer
VALUES (40, '000040', 2, 'Alpine Ski House', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (41, '000041', NULL, 'World Wide Importers', 'Retail');
INSERT INTO DimCustomer
VALUES (42, '000042', NULL, 'Margies Travel', 'Travel and Leisure');
INSERT INTO DimCustomer
VALUES (43, '000043', NULL, 'Coho Vineyard and Winery', 'Food and Beverages');
INSERT INTO DimCustomer
VALUES (44, '000044', NULL, 'Contoso Ltd', 'Retail');
INSERT INTO DimCustomer
VALUES (45, '000045', 1, 'Northwind Traders', 'Retail');
-- Create indexes on the DimCustomer table
CREATE CLUSTERED INDEX cids_DimCustomer_CustomerKey ON DimCustomer(CustomerKey);
CREATE NONCLUSTERED INDEX idx_DimCustomer_CustomerName ON DimCustomer(CustomerName);
CREATE NONCLUSTERED INDEX idx_DimCustomer_CustomerType ON DimCustomer(CustomerType);

-- Create the DimProduct table
CREATE TABLE DimProduct
(ProductKey integer NOT NULL,
 ProductAltKey integer NOT NULL,
 ProductName nvarchar(20) NOT NULL,
 ProductType nvarchar(10) NOT NULL);
DECLARE @LoopInt integer
SET @LoopInt = 1
WHILE @LoopInt <= 4001
BEGIN
	INSERT INTO DimProduct
	VALUES
	(
		@LoopInt, 
		@LoopInt, 
		CONCAT('Product ', CONVERT(nvarchar(4), @LoopInt)), 
		CONCAT('Product ', LEFT(CONVERT(nvarchar(4), @LoopInt),2))
	);
	SET @LoopInt = @LoopInt + 1;
END;

-- Create indexes on the DimProduct table
CREATE CLUSTERED INDEX cids_DimProduct_ProductKey ON DimProduct(ProductKey);
CREATE NONCLUSTERED INDEX idx_DimProduct_ProductName ON DimProduct(ProductName);
CREATE NONCLUSTERED INDEX idx_DimProduct_ProductType ON DimProduct(ProductType);

--DROP TABLE [dbo].[FactOrder];
--DROP TABLE [dbo].[FactOrderCS];
-- Create a fact table
SELECT	d.DateKey, 
		c.CustomerKey, 
		P.ProductKey, 
		d.DayNumberOfWeek Quantity, 
		d.DayNumberOfMonth SalesAmount, 
		c.CustomerType + N' ' + p.ProductType AS OrderDescription
INTO FactOrder
FROM DimDate d
CROSS JOIN DimCustomer c
CROSS JOIN DimProduct p;

CREATE CLUSTERED INDEX cids_FactOrder_DateKey ON FactOrder(DateKey);
CREATE NONCLUSTERED INDEX cids_FactOrder_CustomerKey ON FactOrder(CustomerKey);
CREATE NONCLUSTERED INDEX cids_FactOrder_ProductKey ON FactOrder(ProductKey);

SELECT *
INTO FactOrderCS
FROM FactOrder;
