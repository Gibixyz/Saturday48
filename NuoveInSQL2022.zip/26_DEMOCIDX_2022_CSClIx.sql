USE DemoDW22;
GO

-- Create a columnstore index on the copied table
--DROP INDEX csidx_FactOrderNCS ON [dbo].[FactOrderCS]

SET STATISTICS TIME ON;
SET STATISTICS IO ON;
CREATE CLUSTERED COLUMNSTORE INDEX csidx_FactOrderCSClust ON FactOrderCSo ORDER(DateKey);
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
-- Empty the cache again
CHECKPOINT;
DBCC FREEPROCCACHE;
DBCC DROPCLEANBUFFERS;

-- Test the columnstore index
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SET STATISTICS XML ON;
SELECT	d.CalendarYear, 
		d.MonthNumberOfYear, 
		c.CustomerType, 
		p.ProductName, 
		SUM(o.Quantity) ItemsSold, 
		SUM(o.SalesAmount) TotalRevenue
FROM FactOrderCSo o
JOIN DimDate d ON o.DateKey = d.DateKey
JOIN DimCustomer c ON o.CustomerKey = c.CustomerKey
JOIN DimProduct p ON o.ProductKey = p.ProductKey
WHERE d.FullDateAlternateKey BETWEEN (DATEADD(month, -3, getdate())) AND (getdate())
GROUP BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductName
ORDER BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductName;
SET STATISTICS XML OFF;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

-- Empty the cache again
CHECKPOINT;
DBCC FREEPROCCACHE;
DBCC DROPCLEANBUFFERS;

-- Test the columnstore index
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SET STATISTICS XML ON;
SELECT	d.CalendarYear, 
		d.MonthNumberOfYear, 
		c.CustomerType, 
		p.ProductType, 
		SUM(o.Quantity) ItemsSold, 
		SUM(o.SalesAmount) TotalRevenue
FROM FactOrderCSo o
JOIN DimDate d ON o.DateKey = d.DateKey
JOIN DimCustomer c ON o.CustomerKey = c.CustomerKey
JOIN DimProduct p ON o.ProductKey = p.ProductKey
WHERE d.FullDateAlternateKey BETWEEN (DATEADD(month, -3, getdate())) AND (getdate())
GROUP BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductType
ORDER BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductType;
SET STATISTICS XML OFF;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

SELECT * FROM sys.column_store_row_groups

DELETE
FROM FactOrderCS 
--SELECT * FROM FactOrderCS
WHERE [DateKey] BETWEEN 20211012 AND 20211017

INSERT INTO [dbo].[FactOrderCS]
SELECT DateKey, CustomerKey, ProductKey, Quantity, SalesAmount, OrderDescription
FROM [dbo].[FactOrder]
WHERE [DateKey] BETWEEN 20211012 AND 20211017

ALTER INDEX csidx_FactOrderCSClust ON FactOrderCS REBUILD