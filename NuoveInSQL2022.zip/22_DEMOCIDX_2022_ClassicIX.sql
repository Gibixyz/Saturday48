
USE DemoDW22;
GO


-- Empty the cache
CHECKPOINT;
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
-- View index usage and execution statistics
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SET STATISTICS XML ON;
SELECT	d.CalendarYear, 
		d.MonthNumberOfYear, 
		c.CustomerType, 
		p.ProductName, 
		SUM(o.Quantity) AS ItemsSold, 
		SUM(o.SalesAmount) AS TotalRevenue
FROM dbo.FactOrder o
INNER JOIN dbo.DimDate d ON o.DateKey = d.DateKey
INNER JOIN dbo.DimCustomer c ON o.CustomerKey = c.CustomerKey
INNER JOIN dbo.DimProduct p ON o.ProductKey = p.ProductKey
WHERE d.FullDateAlternateKey BETWEEN (DATEADD(month, -3, getdate())) AND (getdate())
GROUP BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductName
ORDER BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductName;
SET STATISTICS XML OFF;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

-- Empty the cache
CHECKPOINT;
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
-- View index usage and execution statistics
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SET STATISTICS XML ON;
SELECT	d.CalendarYear, 
		d.MonthNumberOfYear, 
		c.CustomerType, 
		p.ProductType, 
		SUM(o.Quantity) AS ItemsSold, 
		SUM(o.SalesAmount) AS TotalRevenue
FROM dbo.FactOrder o
INNER JOIN dbo.DimDate d ON o.DateKey = d.DateKey
INNER JOIN dbo.DimCustomer c ON o.CustomerKey = c.CustomerKey
INNER JOIN dbo.DimProduct p ON o.ProductKey = p.ProductKey
WHERE d.FullDateAlternateKey BETWEEN (DATEADD(month, -3, getdate())) AND (getdate())
GROUP BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductType
ORDER BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductType;
SET STATISTICS XML OFF;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
