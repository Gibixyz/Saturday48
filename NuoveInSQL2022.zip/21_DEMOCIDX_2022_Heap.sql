USE DemoDW22;
GO

CHECKPOINT;
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;

-- View index usage and execution statistics
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SET STATISTICS XML ON;
SELECT	d.CalendarYear, 
		d.MonthNumberOfYear, 
		c.CustomerType, 
		p.ProductName, 
		SUM(o.Quantity) ItemsSold, 
		SUM(o.SalesAmount) TotalRevenue
FROM FactOrderCS o
JOIN DimDate d ON o.DateKey = d.DateKey
JOIN DimCustomer c ON o.CustomerKey = c.CustomerKey
JOIN DimProduct p ON o.ProductKey = p.ProductKey
WHERE d.FullDateAlternateKey BETWEEN (DATEADD(month, -3, getdate())) AND (getdate())
GROUP BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductName
ORDER BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductName;
SET STATISTICS XML OFF;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;

CHECKPOINT;
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
-- View index usage and execution statistics
SET STATISTICS TIME ON;
SET STATISTICS IO ON;
SET STATISTICS XML ON;
SELECT	d.CalendarYear, 
		d.MonthNumberOfYear, 
		c.CustomerType, 
		p.ProductType, 
		SUM(o.Quantity) ItemsSold, 
		SUM(o.SalesAmount) TotalRevenue
FROM FactOrderCS o
JOIN DimDate d ON o.DateKey = d.DateKey
JOIN DimCustomer c ON o.CustomerKey = c.CustomerKey
JOIN DimProduct p ON o.ProductKey = p.ProductKey
WHERE d.FullDateAlternateKey BETWEEN (DATEADD(month, -3, getdate())) AND (getdate())
GROUP BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductType
ORDER BY d.CalendarYear, d.MonthNumberOfYear, c.CustomerType, p.ProductType;
SET STATISTICS XML OFF;
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
